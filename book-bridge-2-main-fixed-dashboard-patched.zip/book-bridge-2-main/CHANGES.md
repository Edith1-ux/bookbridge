# BookBridge – fixes in this zip

## Login
- js/api.js: finds the Django server automatically when the page is opened from
  VS Code Live Server / another port / file:// (was always "/api" -> login failed there)
- js/api.js: clear error messages (server not running, wrong address)
- backend/config/settings/base.py: 20 login tries/minute (was 10), Live Server allowed by CORS in local dev
- browse-1.html renamed to browse.html (the server looks for browse.html -> "Buy Books" was a 404)
- backend/apps/users/test_login_flow.py: new login tests

## Messages
- backend/apps/chat/*, js/app.js, js/api.js, style.css, css/style.css (chat screen, conversations, reply box)

## Demo accounts (after `python backend/manage.py seed_db`)
- Student: student@rcti.ac.in / Student@123
- Admin:   admin@bookbridge.edu / Admin@123456
