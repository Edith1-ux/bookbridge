import logging
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from .models import ChatMessage
from .serializers import ChatMessageSerializer
from apps.users.models import User

logger = logging.getLogger('apps.chat')


def _messages_for(user, other_email=None):
    """
    All messages the user sent or received. If `other_email` is given, only the
    two-way conversation between the user and that person.
    """
    queryset = ChatMessage.objects.filter(
        Q(sender=user) | Q(receiver_email__iexact=user.email)
    )
    if other_email:
        queryset = queryset.filter(
            Q(sender=user, receiver_email__iexact=other_email) |
            Q(sender__email__iexact=other_email, receiver_email__iexact=user.email)
        )
    return queryset.select_related('sender').order_by('timestamp')


class ChatMessageListCreateView(generics.ListCreateAPIView):
    serializer_class = ChatMessageSerializer
    permission_classes = [permissions.IsAuthenticated]
    # The dashboard expects a plain array. With the project-wide pagination (20 per page)
    # the API returned {count, next, results} and only the 20 OLDEST messages.
    pagination_class = None

    def get_queryset(self):
        # Supports /api/messages/?with=<email> (the old code ignored "with").
        return _messages_for(self.request.user, self.request.query_params.get('with'))

    def perform_create(self, serializer):
        msg = serializer.save(sender=self.request.user)
        # Notify the recipient if they are a registered user
        if msg.receiver_email:
            try:
                recipient = User.objects.filter(email__iexact=msg.receiver_email).first()
                if recipient and recipient != self.request.user:
                    from apps.notifications.models import push_notification
                    preview = msg.text if len(msg.text) <= 100 else msg.text[:100] + '...'
                    push_notification(
                        recipient=recipient,
                        title=f"New message from {self.request.user.full_name or self.request.user.email}",
                        message=preview,
                        notification_type='MESSAGE',
                        link='/dashboard.html?tab=messages'
                    )
            except Exception:
                logger.exception(
                    "Failed to create notification for chat message to %s", msg.receiver_email
                )


class ChatInboxView(APIView):
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        messages = _messages_for(request.user, request.query_params.get('with'))
        serializer = ChatMessageSerializer(messages, many=True, context={'request': request})
        return Response(serializer.data, status=status.HTTP_200_OK)
