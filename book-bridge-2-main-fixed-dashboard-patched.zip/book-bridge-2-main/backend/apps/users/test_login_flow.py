from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework import status

from apps.users.models import User


class LoginFlowTests(TestCase):
    """Login regression tests (register -> login round trip)."""

    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            email='student@rcti.ac.in', password='Student@123',
            full_name='Demo Student', role='STUDENT'
        )

    def _login(self, email, password):
        return self.client.post('/api/login/', {'email': email, 'password': password}, format='json')

    def test_login_ok_and_returns_tokens(self):
        res = self._login('student@rcti.ac.in', 'Student@123')
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertIn('access', res.data)
        self.assertIn('refresh', res.data)
        self.assertEqual(res.data['user']['email'], 'student@rcti.ac.in')

    def test_login_email_is_case_insensitive(self):
        self.assertEqual(self._login('Student@RCTI.ac.in', 'Student@123').status_code, 200)

    def test_wrong_password_is_401_with_message(self):
        res = self._login('student@rcti.ac.in', 'wrong')
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)
        self.assertIn('error', res.data)

    def test_register_with_padded_password_then_login_with_trimmed(self):
        """Registration trims the password, and the login page trims it too, so they match."""
        reg = self.client.post('/api/register/', {
            'full_name': 'Spacey', 'name': 'Spacey', 'email': 'spacey@example.com',
            'password': '  Pass@1234  ', 'branch': 'CE', 'semester': 1,
        }, format='json')
        self.assertEqual(reg.status_code, status.HTTP_201_CREATED)
        self.assertEqual(self._login('spacey@example.com', 'Pass@1234').status_code, 200)

    def test_inactive_account_cannot_login(self):
        self.user.is_active = False
        self.user.save()
        res = self._login('student@rcti.ac.in', 'Student@123')
        self.assertIn(res.status_code, (401, 403))
